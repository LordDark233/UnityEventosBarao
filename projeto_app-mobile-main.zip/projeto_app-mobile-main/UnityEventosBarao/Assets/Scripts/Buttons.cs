using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    // Start is called before the first frame update
    public void EventList()
    {
        SceneManager.LoadScene("EventList");
    }
    public void Login()
    {
        SceneManager.LoadScene("Login");
    }
    public void Tela3()
    {
        SceneManager.LoadScene("Tela3");
    }
    public void Tela4()
    {
        SceneManager.LoadScene("Tela4");
    }
    public void Tela5()
    {
        SceneManager.LoadScene("Tela5");
    }
    public void Tela6()
    {
        SceneManager.LoadScene("Tela6");
    }
    public void Tela7()
    {
        SceneManager.LoadScene("Tela7");
    }
    public void Tela8()
    {
        SceneManager.LoadScene("Tela8");
    }
    public void Tela9()
    {
        SceneManager.LoadScene("Tela9");
    }
}
